type Env = {
  DB: D1Database;
  ADMIN_USER: string;
  ADMIN_PASSWORD: string;
  SHOP_WHATSAPP?: string;
  SHOP_UPI?: string;
};

type MenuItem = {
  id: string; name: string; category: string; price: number; desc: string;
  imageUrl: string; badge: string; available: boolean;
};

const DEFAULT_MENU: MenuItem[] = [
  { id: "ic-01", name: "Madagascar Vanilla Bean", category: "Classic Scoops", price: 90, desc: "Slow-churned with real cured bourbon vanilla beans & cream.", imageUrl: "https://images.unsplash.com/photo-1570197788417-0e82375c9371?w=500&auto=format&fit=crop&q=80", badge: "Classic", available: true },
  { id: "ic-02", name: "Belgian Dark Truffle", category: "Classic Scoops", price: 120, desc: "70% single-origin Belgian cocoa folded with dark chocolate curls.", imageUrl: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=500&auto=format&fit=crop&q=80", badge: "Bestseller", available: true },
  { id: "ic-03", name: "Wild Strawberry Swirl", category: "Artisan Gelato", price: 110, desc: "Fresh Mahabaleshwar strawberry reduction rippled in cream.", imageUrl: "https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=500&auto=format&fit=crop&q=80", badge: "Fresh Fruit", available: true },
  { id: "ic-04", name: "Sicilian Pistachio Praline", category: "Artisan Gelato", price: 140, desc: "Roasted green pistachios with honey roasted caramelized nut bits.", imageUrl: "https://images.unsplash.com/photo-1576506295286-5cda18df43e7?w=500&auto=format&fit=crop&q=80", badge: "Chef's Special", available: true },
  { id: "ic-05", name: "Crunchy Nutty Waffle Cone", category: "Waffle Cones", price: 130, desc: "Double scoop of choice in freshly pressed butter-cinnamon cone.", imageUrl: "https://images.unsplash.com/photo-1505394033641-40c6ad1178d7?w=500&auto=format&fit=crop&q=80", badge: "Popular", available: true },
  { id: "ic-06", name: "Death by Chocolate Sundae", category: "Sundaes & Bowls", price: 180, desc: "Warm chocolate brownie, dark scoop, hot fudge, nuts, cherry.", imageUrl: "https://images.unsplash.com/photo-1563227812-0ea4c22e6cc8?w=500&auto=format&fit=crop&q=80", badge: "Indulgent", available: true },
];

const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const fail = (message: string, status = 400) => json({ error: message }, status);
const clean = (v: unknown, max = 1000) => String(v ?? "").trim().slice(0, max);
const asBool = (v: unknown) => v === true || v === 1 || v === "1";

async function seed(db: D1Database, env: Env) {
  const row = await db.prepare("SELECT id FROM shop_settings WHERE id='main'").first();
  if (!row) await db.prepare("INSERT INTO shop_settings (id, phone, upi) VALUES ('main', ?, ?)")
    .bind(env.SHOP_WHATSAPP || "919876543210", env.SHOP_UPI || "scoopcraft@okaxis").run();
  const count = await db.prepare("SELECT COUNT(*) AS n FROM menu_items").first<{ n: number }>();
  if (!count?.n) {
    const stmt = db.prepare("INSERT OR IGNORE INTO menu_items (id,name,category,price,description,image_url,badge,available) VALUES (?,?,?,?,?,?,?,?)");
    for (const i of DEFAULT_MENU) await stmt.bind(i.id, i.name, i.category, i.price, i.desc, i.imageUrl, i.badge, i.available ? 1 : 0).run();
  }
}
async function isAdmin(request: Request, env: Env) {
  const token = request.headers.get("x-admin-token");
  if (!token) return false;
  const row = await env.DB.prepare("SELECT token FROM admin_sessions WHERE token=? AND expires_at > ?").bind(token, Date.now()).first();
  return !!row;
}
async function requireAdmin(request: Request, env: Env) {
  return await isAdmin(request, env) ? null : fail("Admin login required", 401);
}
function mapItem(r: any): MenuItem {
  return { id: r.id, name: r.name, category: r.category, price: Number(r.price), desc: r.description ?? "", imageUrl: r.image_url ?? "", badge: r.badge ?? "", available: asBool(r.available) };
}
function mapOrder(r: any) {
  return { ref: r.ref, createdAt: r.created_at, customer: r.customer_name, orderType: r.order_type, items: JSON.parse(r.items_json), total: Number(r.total), pickupDate: r.pickup_date ?? "", pickupTime: r.pickup_time ?? "", inscription: r.inscription ?? "", notes: r.notes ?? "", status: r.status };
}

export const onRequest: PagesFunction<Env> = async ({ request, env }) => {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
  const [resource, id] = path;
  try {
    if (!env.ADMIN_USER || !env.ADMIN_PASSWORD) return fail("Admin secrets are not configured. Set ADMIN_USER and ADMIN_PASSWORD in Cloudflare Pages settings.", 503);
    await seed(env.DB, env);

    if (resource === "login" && request.method === "POST") {
      const body = await request.json() as any;
      if (clean(body.user, 100) !== env.ADMIN_USER || clean(body.pass, 200) !== env.ADMIN_PASSWORD) return fail("Invalid credentials", 401);
      const token = crypto.randomUUID() + crypto.randomUUID().replaceAll("-", "");
      const expiresAt = Date.now() + 12 * 60 * 60 * 1000;
      await env.DB.prepare("INSERT INTO admin_sessions (token, expires_at) VALUES (?,?)").bind(token, expiresAt).run();
      const settings = await env.DB.prepare("SELECT phone, upi FROM shop_settings WHERE id='main'").first<any>();
      return json({ token, phone: settings?.phone ?? env.SHOP_WHATSAPP ?? "", upi: settings?.upi ?? env.SHOP_UPI ?? "" });
    }

    if (resource === "menu" && request.method === "GET" && !id) {
      const { results } = await env.DB.prepare("SELECT * FROM menu_items ORDER BY id").all<any>();
      return json(results.map(mapItem));
    }
    if (resource === "settings" && request.method === "GET") {
      const settings = await env.DB.prepare("SELECT phone, upi FROM shop_settings WHERE id='main'").first<any>();
      return json({ phone: settings?.phone ?? env.SHOP_WHATSAPP ?? "", upi: settings?.upi ?? env.SHOP_UPI ?? "" });
    }

    if (resource === "orders" && request.method === "POST") {
      const body = await request.json() as any;
      const customer = clean(body.customer, 120);
      const orderType = clean(body.orderType || "Takeaway", 30);
      const pickupDate = clean(body.pickupDate, 10);
      const pickupTime = clean(body.pickupTime, 5);
      const inscription = clean(body.inscription, 80);
      const notes = clean(body.notes, 1000);
      const requested = Array.isArray(body.items) ? body.items : [];
      if (!customer || !requested.length || requested.length > 30) return fail("Customer name and at least one item are required");
      if (requested.some((x: any) => !Number.isInteger(Number(x.qty)) || Number(x.qty) < 1 || Number(x.qty) > 99)) return fail("Invalid item quantity");
      const cakes = new Set(["Cakes & Desserts", "Cakes & Bento"]);
      const items: any[] = [];
      for (const requestedItem of requested) {
        const row = await env.DB.prepare("SELECT id,name,category,price,available FROM menu_items WHERE id=?").bind(clean(requestedItem.id, 100)).first<any>();
        if (!row || !asBool(row.available)) return fail("An item in your order is no longer available. Please refresh the menu.", 409);
        const qty = Number(requestedItem.qty);
        items.push({ id: row.id, name: row.name, category: row.category, qty, lineTotal: Number(row.price) * qty });
      }
      if (items.some(i => cakes.has(i.category)) && !pickupDate) return fail("Please choose a preorder / pickup date for your cake order");
      const total = items.reduce((sum, item) => sum + item.lineTotal, 0);
      const ref = "ICE-" + crypto.randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase();
      const createdAt = new Date().toISOString();
      const status = "Pending confirmation";
      await env.DB.prepare("INSERT INTO orders (ref,created_at,customer_name,order_type,items_json,total,pickup_date,pickup_time,inscription,notes,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
        .bind(ref, createdAt, customer, orderType, JSON.stringify(items), total, pickupDate || null, pickupTime || null, inscription, notes, status).run();
      return json({ ref, createdAt, customer, orderType, items, total, pickupDate, pickupTime, inscription, notes, status }, 201);
    }
    if (resource === "orders" && request.method === "GET") {
      const refs = (url.searchParams.get("refs") || "").split(",").map(x => x.trim()).filter(x => /^ICE-[A-F0-9]{10}$/.test(x)).slice(0, 50);
      if (await isAdmin(request, env)) {
        const { results } = await env.DB.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200").all<any>();
        return json(results.map(mapOrder));
      }
      if (!refs.length) return fail("Provide saved order references", 400);
      const placeholders = refs.map(() => "?").join(",");
      const { results } = await env.DB.prepare(`SELECT * FROM orders WHERE ref IN (${placeholders}) ORDER BY created_at DESC`).bind(...refs).all<any>();
      return json(results.map(mapOrder));
    }
    if (resource === "orders" && id && request.method === "PUT") {
      const denied = await requireAdmin(request, env); if (denied) return denied;
      const body = await request.json() as any;
      const status = clean(body.status, 50);
      if (!["Pending confirmation", "Confirmed", "Preparing", "Ready for pickup", "Completed", "Cancelled"].includes(status)) return fail("Invalid order status");
      const result = await env.DB.prepare("UPDATE orders SET status=? WHERE ref=?").bind(status, id).run();
      if (!result.meta.changes) return fail("Order not found", 404);
      return json({ ok: true, ref: id, status });
    }

    if (resource === "menu" || resource === "settings") {
      const denied = await requireAdmin(request, env); if (denied) return denied;
      if (resource === "menu" && id === "reset" && request.method === "POST") {
        for (const i of DEFAULT_MENU) await env.DB.prepare("INSERT INTO menu_items (id,name,category,price,description,image_url,badge,available) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,price=excluded.price,description=excluded.description,image_url=excluded.image_url,badge=excluded.badge,available=excluded.available")
          .bind(i.id, i.name, i.category, i.price, i.desc, i.imageUrl, i.badge, i.available ? 1 : 0).run();
        const { results } = await env.DB.prepare("SELECT * FROM menu_items ORDER BY id").all<any>(); return json(results.map(mapItem));
      }
      if (resource === "menu" && id && request.method === "PUT") {
        const b = await request.json() as any;
        const item: MenuItem = { id, name: clean(b.name, 160), category: clean(b.category, 80), price: Math.max(0, Math.round(Number(b.price) || 0)), desc: clean(b.desc, 1000), imageUrl: clean(b.imageUrl, 500000), badge: clean(b.badge, 80), available: b.available !== false };
        if (!item.name || !item.category) return fail("Name and category are required");
        await env.DB.prepare("INSERT INTO menu_items (id,name,category,price,description,image_url,badge,available) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,price=excluded.price,description=excluded.description,image_url=excluded.image_url,badge=excluded.badge,available=excluded.available")
          .bind(item.id,item.name,item.category,item.price,item.desc,item.imageUrl,item.badge,item.available ? 1 : 0).run();
        return json(item);
      }
      if (resource === "menu" && id && request.method === "DELETE") {
        await env.DB.prepare("DELETE FROM menu_items WHERE id=?").bind(id).run(); return json({ ok: true });
      }
      if (resource === "settings" && request.method === "PUT") {
        const b = await request.json() as any;
        const phone = clean(b.phone, 30); const upi = clean(b.upi, 120);
        if (phone && !/^[+0-9 ()-]{8,30}$/.test(phone)) return fail("Enter a valid WhatsApp number with country code");
        await env.DB.prepare("UPDATE shop_settings SET phone=?, upi=? WHERE id='main'").bind(phone, upi).run();
        return json({ phone, upi });
      }
    }
    return fail("Not found", 404);
  } catch (error) {
    console.error("Icespot API error", error);
    return fail("Server error. Check the Cloudflare Pages function logs.", 500);
  }
};
